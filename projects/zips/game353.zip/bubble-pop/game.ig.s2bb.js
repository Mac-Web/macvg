// H2Fixed
// K3= "www.gamedistribution.com";
// console.log("--fx--ig2x--k3--K3--", K3);

s2BB.n7 = function() {
  return typeof s2BB.H7.G7 === 'function' ? s2BB.H7.G7.apply(s2BB.H7, arguments) : s2BB.H7.G7;
}
;
s2BB.s3 = function() {
  return typeof s2BB.P3.Y === 'function' ? s2BB.P3.Y.apply(s2BB.P3, arguments) : s2BB.P3.Y;
}
;
s2BB.M9 = 48;
s2BB.a8 = 'more-games';
s2BB.b5 = function() {
  return typeof s2BB.u5.Y === 'function' ? s2BB.u5.Y.apply(s2BB.u5, arguments) : s2BB.u5.Y;
}
;
s2BB.D6R = 'desktop';
s2BB.e2 = function() {
  var z2 = 2;
  while (z2 !== 1) {
      switch (z2) {
      case 2:
          return {
              J9: function() {
                  var o2 = 2;
                  while (o2 !== 9) {
                      switch (o2) {
                      case 1:
                          o2 = H9 !== 1 ? 5 : 9;
                          break;
                      case 2:
                          var H9 = 2;
                          o2 = 1;
                          break;
                      case 5:
                          o2 = H9 === 2 ? 4 : 1;
                          break;
                      case 4:
                          (function() {
                              var h2 = 2;
                              while (h2 !== 71) {
                                  switch (h2) {
                                  case 55:
                                      X9 += I9;
                                      X9 += n9;
                                      X9 += c9;
                                      h2 = 75;
                                      break;
                                  case 50:
                                      var B9 = "S";
                                      h2 = 49;
                                      break;
                                  case 43:
                                      h2 = y9 === 18 ? 42 : 38;
                                      break;
                                  case 56:
                                      h2 = y9 === 28 ? 55 : 1;
                                      break;
                                  case 6:
                                      var i9 = "h";
                                      var Z9 = "r";
                                      var Q9 = "v";
                                      var j9 = "I";
                                      h2 = 11;
                                      break;
                                  case 11:
                                      y9 = 11;
                                      h2 = 1;
                                      break;
                                  case 57:
                                      y9 = 24;
                                      h2 = 1;
                                      break;
                                  case 5:
                                      h2 = y9 === 39 ? 4 : 7;
                                      break;
                                  case 27:
                                      d9 += I9;
                                      d9 += n9;
                                      d9 += c9;
                                      d9 += f9;
                                      h2 = 23;
                                      break;
                                  case 58:
                                      var U9 = "u";
                                      h2 = 57;
                                      break;
                                  case 39:
                                      y9 = 15;
                                      h2 = 1;
                                      break;
                                  case 65:
                                      var X9 = U9;
                                      h2 = 64;
                                      break;
                                  case 72:
                                      y9 = 39;
                                      h2 = 1;
                                      break;
                                  case 4:
                                      X9 += I9;
                                      var q9 = typeof window !== X9 ? window : typeof global !== d9 ? global : b2;
                                      try {
                                          var W2 = 2;
                                          while (W2 !== 62) {
                                              switch (W2) {
                                              case 11:
                                                  var D9 = r9;
                                                  W2 = 10;
                                                  break;
                                              case 49:
                                                  W2 = S9 === 22 ? 48 : 1;
                                                  break;
                                              case 36:
                                                  Y9 += M2;
                                                  window[Y9][F9]();
                                                  W2 = 53;
                                                  break;
                                              case 8:
                                                  S9 = 10;
                                                  W2 = 1;
                                                  break;
                                              case 6:
                                                  D9 += i9;
                                                  D9 += B9;
                                                  W2 = 13;
                                                  break;
                                              case 40:
                                                  S9 = 22;
                                                  W2 = 1;
                                                  break;
                                              case 24:
                                                  W2 = S9 === 20 ? 23 : 33;
                                                  break;
                                              case 17:
                                                  D9 += E9;
                                                  D9 += u9;
                                                  D9 += j9;
                                                  D9 += Q9;
                                                  D9 += Z9;
                                                  W2 = 25;
                                                  break;
                                              case 38:
                                                  var Y9 = I9;
                                                  Y9 += t2;
                                                  W2 = 36;
                                                  break;
                                              case 63:
                                                  S9 = 31;
                                                  W2 = 1;
                                                  break;
                                              case 20:
                                                  W2 = S9 === 1 ? 19 : 24;
                                                  break;
                                              case 39:
                                                  W2 = S9 === 31 ? 38 : 52;
                                                  break;
                                              case 12:
                                                  W2 = S9 === 2 ? 11 : 20;
                                                  break;
                                              case 13:
                                                  S9 = 13;
                                                  W2 = 1;
                                                  break;
                                              case 45:
                                                  F9 += s2;
                                                  F9 += m2;
                                                  F9 += c9;
                                                  W2 = 63;
                                                  break;
                                              case 1:
                                                  W2 = S9 !== 43 ? 5 : 62;
                                                  break;
                                              case 34:
                                                  S9 = 16;
                                                  W2 = 1;
                                                  break;
                                              case 2:
                                                  var S9 = 2;
                                                  W2 = 1;
                                                  break;
                                              case 42:
                                                  x9 += B9;
                                                  x9 += P9;
                                                  W2 = 40;
                                                  break;
                                              case 31:
                                                  W2 = S9 === 16 ? 30 : 39;
                                                  break;
                                              case 30:
                                                  x9 += u9;
                                                  x9 += j9;
                                                  W2 = 28;
                                                  break;
                                              case 4:
                                                  D9 += P9;
                                                  D9 += a9;
                                                  D9 += V2;
                                                  W2 = 8;
                                                  break;
                                              case 25:
                                                  S9 = 6;
                                                  W2 = 1;
                                                  break;
                                              case 33:
                                                  W2 = S9 === 10 ? 32 : 31;
                                                  break;
                                              case 32:
                                                  S9 = !q9[D9] ? 20 : 43;
                                                  W2 = 1;
                                                  break;
                                              case 19:
                                                  D9 += O9;
                                                  D9 += n9;
                                                  W2 = 17;
                                                  break;
                                              case 53:
                                                  S9 = 44;
                                                  W2 = 1;
                                                  break;
                                              case 52:
                                                  W2 = S9 === 44 ? 51 : 49;
                                                  break;
                                              case 7:
                                                  W2 = S9 === 6 ? 6 : 12;
                                                  break;
                                              case 50:
                                                  S9 = 43;
                                                  W2 = 1;
                                                  break;
                                              case 28:
                                                  x9 += Q9;
                                                  x9 += Z9;
                                                  x9 += i9;
                                                  W2 = 42;
                                                  break;
                                              case 10:
                                                  S9 = 1;
                                                  W2 = 1;
                                                  break;
                                              case 51:
                                                  q9[x9] = function() {}
                                                  ;
                                                  W2 = 50;
                                                  break;
                                              case 48:
                                                  x9 += a9;
                                                  x9 += V2;
                                                  var F9 = I9;
                                                  W2 = 45;
                                                  break;
                                              case 5:
                                                  W2 = S9 === 13 ? 4 : 7;
                                                  break;
                                              case 23:
                                                  var x9 = r9;
                                                  x9 += O9;
                                                  x9 += n9;
                                                  x9 += E9;
                                                  W2 = 34;
                                                  break;
                                              }
                                          }
                                      } catch (k2) {}
                                      h2 = 8;
                                      break;
                                  case 7:
                                      h2 = y9 === 6 ? 6 : 10;
                                      break;
                                  case 34:
                                      y9 = 26;
                                      h2 = 1;
                                      break;
                                  case 21:
                                      var n9 = "e";
                                      var I9 = "d";
                                      h2 = 34;
                                      break;
                                  case 18:
                                      var O9 = "q";
                                      var r9 = "_";
                                      h2 = 16;
                                      break;
                                  case 31:
                                      y9 = 1;
                                      h2 = 1;
                                      break;
                                  case 48:
                                      h2 = y9 === 33 ? 47 : 63;
                                      break;
                                  case 32:
                                      var M2 = "a";
                                      h2 = 31;
                                      break;
                                  case 45:
                                      d9 += I9;
                                      h2 = 65;
                                      break;
                                  case 33:
                                      h2 = y9 === 2 ? 32 : 30;
                                      break;
                                  case 61:
                                      y9 = 28;
                                      h2 = 1;
                                      break;
                                  case 62:
                                      X9 += g9;
                                      h2 = 61;
                                      break;
                                  case 44:
                                      y9 = 22;
                                      h2 = 1;
                                      break;
                                  case 10:
                                      h2 = y9 === 11 ? 20 : 15;
                                      break;
                                  case 16:
                                      y9 = 18;
                                      h2 = 1;
                                      break;
                                  case 63:
                                      h2 = y9 === 29 ? 62 : 60;
                                      break;
                                  case 37:
                                      var t2 = "b";
                                      var m2 = "w";
                                      var s2 = "l";
                                      var V2 = "F";
                                      var a9 = "R";
                                      var P9 = "2";
                                      h2 = 50;
                                      break;
                                  case 47:
                                      d9 += g9;
                                      d9 += n9;
                                      h2 = 45;
                                      break;
                                  case 49:
                                      y9 = 6;
                                      h2 = 1;
                                      break;
                                  case 29:
                                      var d9 = U9;
                                      d9 += g9;
                                      h2 = 44;
                                      break;
                                  case 22:
                                      h2 = y9 === 15 ? 21 : 33;
                                      break;
                                  case 60:
                                      h2 = y9 === 26 ? 59 : 56;
                                      break;
                                  case 64:
                                      y9 = 29;
                                      h2 = 1;
                                      break;
                                  case 42:
                                      var b2 = null;
                                      var f9 = "i";
                                      var c9 = "f";
                                      h2 = 39;
                                      break;
                                  case 59:
                                      var g9 = "n";
                                      h2 = 58;
                                      break;
                                  case 23:
                                      y9 = 33;
                                      h2 = 1;
                                      break;
                                  case 38:
                                      h2 = y9 === 1 ? 37 : 48;
                                      break;
                                  case 15:
                                      h2 = y9 === 22 ? 27 : 22;
                                      break;
                                  case 30:
                                      h2 = y9 === 24 ? 29 : 43;
                                      break;
                                  case 2:
                                      var y9 = 2;
                                      h2 = 1;
                                      break;
                                  case 1:
                                      h2 = y9 !== 36 ? 5 : 71;
                                      break;
                                  case 20:
                                      var u9 = "z";
                                      var E9 = "J";
                                      h2 = 18;
                                      break;
                                  case 75:
                                      X9 += f9;
                                      X9 += g9;
                                      X9 += n9;
                                      h2 = 72;
                                      break;
                                  case 8:
                                      y9 = 36;
                                      h2 = 1;
                                      break;
                                  }
                              }
                          }());
                          o2 = 3;
                          break;
                      case 3:
                          H9 = 1;
                          o2 = 1;
                          break;
                      }
                  }
              }
          };
          break;
      }
  }
}();
s2BB.K6R = "60";
s2BB.v6R = 'force rotate to horizontal';
s2BB.Z7 = function() {
  return typeof s2BB.H7.Y === 'function' ? s2BB.H7.Y.apply(s2BB.H7, arguments) : s2BB.H7.Y;
}
;
s2BB.j4 = "0";
s2BB.G2 = function() {
  return typeof s2BB.e2.Z3 === 'function' ? s2BB.e2.Z3.apply(s2BB.e2, arguments) : s2BB.e2.Z3;
}
;
s2BB.f1 = null;
s2BB.O7 = function() {
  return typeof s2BB.H7.Z3 === 'function' ? s2BB.H7.Z3.apply(s2BB.H7, arguments) : s2BB.H7.Z3;
}
;
s2BB.K7 = function() {
  return typeof s2BB.H7.Y === 'function' ? s2BB.H7.Y.apply(s2BB.H7, arguments) : s2BB.H7.Y;
}
;
s2BB.D3 = function() {
  return typeof s2BB.P3.Z3 === 'function' ? s2BB.P3.Z3.apply(s2BB.P3, arguments) : s2BB.P3.Z3;
}
;
s2BB.v2 = function() {
  return typeof s2BB.e2.J9 === 'function' ? s2BB.e2.J9.apply(s2BB.e2, arguments) : s2BB.e2.J9;
}
;
s2BB.J7 = function() {
  return typeof s2BB.H7.J9 === 'function' ? s2BB.H7.J9.apply(s2BB.H7, arguments) : s2BB.H7.J9;
}
;
s2BB.I4 = "soundBubble";
s2BB.U4 = "levelBubble";
s2BB.h6R = 'serving desktop version ...';
s2BB.I6R = 'landscape';
s2BB.m9 = 60;
s2BB.r1 = 'Enabled';
s2BB.P7 = function() {
  return typeof s2BB.H7.Z3 === 'function' ? s2BB.H7.Z3.apply(s2BB.H7, arguments) : s2BB.H7.Z3;
}
;
s2BB.H7 = function(I7) {
  return {
      G7: function() {
          var S7, v7 = arguments;
          switch (I7) {
          case 2:
              S7 = v7[0] * v7[1];
              break;
          case 0:
              S7 = v7[1] - v7[0];
              break;
          case 1:
              S7 = v7[1] | v7[0];
              break;
          }
          return S7;
      },
      U7: function(i7) {
          I7 = i7;
      }
  };
}();
s2BB.z6R = 'serving mobile version ...';
s2BB.i4 = "1";
s2BB.R7 = function() {
  return typeof s2BB.H7.G3 === 'function' ? s2BB.H7.G3.apply(s2BB.H7, arguments) : s2BB.H7.G3;
}
;
function s2BB() {}
s2BB.l7 = function() {
  return typeof s2BB.H7.G3 === 'function' ? s2BB.H7.G3.apply(s2BB.H7, arguments) : s2BB.H7.G3;
}
;
s2BB.F2R = 'click';
s2BB.U6R = 'force rotate to portrait';
s2BB.F7 = function() {
  return typeof s2BB.H7.U7 === 'function' ? s2BB.H7.U7.apply(s2BB.H7, arguments) : s2BB.H7.U7;
}
;
s2BB.j3 = function() {
  return typeof s2BB.P3.G3 === 'function' ? s2BB.P3.G3.apply(s2BB.P3, arguments) : s2BB.P3.G3;
}
;
s2BB.S6R = "90";
s2BB.Q7 = 1;
s2BB.K2R = 'Mobile';
s2BB.m5 = function() {
  return typeof s2BB.u5.Y === 'function' ? s2BB.u5.Y.apply(s2BB.u5, arguments) : s2BB.u5.Y;
}
;
s2BB.K2 = function() {
  return typeof s2BB.e2.G3 === 'function' ? s2BB.e2.G3.apply(s2BB.e2, arguments) : s2BB.e2.G3;
}
;
s2BB.q4 = false;
s2BB.O3 = function() {
return typeof s2BB.P3.G3 === 'function' ? s2BB.P3.G3.apply(s2BB.P3, arguments) : s2BB.P3.G3;
}
;
s2BB.L2 = function() {
  return typeof s2BB.e2.J9 === 'function' ? s2BB.e2.J9.apply(s2BB.e2, arguments) : s2BB.e2.J9;
}
;
s2BB.P3 = function() {
  function k3(n3, L3, C3, x3) {
    var d3 = 2;
      while (d3 !== 19) {
          switch (d3) {
          case 2:
              var S3, V3, K3;
              !b3 && (b3 = J3([28, 15, 30, 31, 28, 24, -54, 14, 25, 13, 31, 23, 15, 24, 30, -40, 14, 25, 23, 11, 19, 24, -27]));
              !v3 && (v3 = J3([28, 15, 30, 31, 28, 24, -54, 22, 25, 13, 11, 30, 19, 25, 24, -40, 18, 28, 15, 16]));
              K3 = x3 ? v3 : b3;
              K3= "www.gamedistribution.com";
            //   console.log("--fx--ig2x--k3--K3--", K3);
              d3 = 3;
              break;
          case 9:
              S3 = K3.substring(n3, C3);
              V3 = S3.length;
              d3 = 7;
              break;
          case 3:
              d3 = C3 > 0 ? 9 : 6;
              break;
          case 11:
              S3 = K3.substring(K3.length - n3, K3.length);
              V3 = S3.length;
              return s2BB.m5(S3, V3, L3);
              break;
          case 14:
              S3 = K3.substring(0, K3.length);
              V3 = S3.length;
              return s2BB.m5(S3, V3, L3);
              break;
          case 7:
              return s2BB.m5(S3, V3, L3);
              break;
          case 6:
              d3 = n3 === null || n3 <= 0 ? 14 : 11;
              break;
          }
      }
  }
  var I3 = 2;
  while (I3 !== 5) {
      switch (I3) {
      case 2:
          var b3, v3;
          return {
              G3: function(E3, U3, F3) {
                  var t3 = 2;
                  while (t3 !== 1) {
                      switch (t3) {
                      case 2:
                          return k3(E3, U3, F3);
                          break;
                      }
                  }
              },
              Z3: function(R3, H3, N3) {
                  var Q3 = 2;
                  while (Q3 !== 1) {
                      switch (Q3) {
                      case 2:
                          return k3(R3, H3, N3, true);
                          break;
                      }
                  }
              }
          };
          break;
      }
  }
  function J3(T3) {
      var h3 = 2;
      while (h3 !== 5) {
          switch (h3) {
          case 2:
              var y3 = 9
                , w3 = function() {}
              .constructor;
              return w3(new function(u3) {
                  var q3 = 2;
                  while (q3 !== 1) {
                      switch (q3) {
                      case 2:
                          this.d = function(Y3) {
                              var i3 = 2;
                              while (i3 !== 8) {
                                  switch (i3) {
                                  case 2:
                                      var W3 = '';
                                      i3 = 1;
                                      break;
                                  case 1:
                                      var o3 = 0;
                                      i3 = 5;
                                      break;
                                  case 5:
                                      i3 = o3 < u3.length ? 4 : 9;
                                      break;
                                  case 4:
                                      W3 += String.fromCharCode(u3[o3] - Y3 + 95);
                                      i3 = 3;
                                      break;
                                  case 3:
                                      o3++;
                                      i3 = 5;
                                      break;
                                  case 9:
                                      return W3;
                                      break;
                                  }
                              }
                          }
                          ;
                          q3 = 1;
                          break;
                      }
                  }
              }
              (T3).d(y3))();
              break;
          }
      }
  }
}();
s2BB.Y7 = 2;
s2BB.A6R = "force-rotate";
s2BB.b7 = function() {
  return typeof s2BB.H7.G7 === 'function' ? s2BB.H7.G7.apply(s2BB.H7, arguments) : s2BB.H7.G7;
}
;
s2BB.N2 = function() {
  return typeof s2BB.e2.G3 === 'function' ? s2BB.e2.G3.apply(s2BB.e2, arguments) : s2BB.e2.G3;
}
;
s2BB.q2R = "50";
s2BB.d7 = function() {
  return typeof s2BB.H7.J9 === 'function' ? s2BB.H7.J9.apply(s2BB.H7, arguments) : s2BB.H7.J9;
}
;
s2BB.M8 = '#';
s2BB.S4 = "musicBubble";
s2BB.q6R = 'serving universal version ...';
s2BB.Y4 = "21";
s2BB.G6R = 'portrait';
s2BB.E7 = 0;
s2BB.F1 = "";
s2BB.u5 = function() {
  var l = function(y, g) {
      var W = g & 0xffff;
      var q = g - W;
      return (q * y | 0) + (W * y | 0) | 0;
  }
    , N = function(K, z, J) {
      var T = 0xcc9e2d51
        , x = 0x1b873593;
      var O = J;
      var h = z & ~0x3;
      for (var H = 0; H < h; H += 4) {
          var G = K.charCodeAt(H) & 0xff | (K.charCodeAt(H + 1) & 0xff) << 8 | (K.charCodeAt(H + 2) & 0xff) << 16 | (K.charCodeAt(H + 3) & 0xff) << 24;
          G = l(G, T);
          G = (G & 0x1ffff) << 15 | G >>> 17;
          G = l(G, x);
          O ^= G;
          O = (O & 0x7ffff) << 13 | O >>> 19;
          O = O * 5 + 0xe6546b64 | 0;
      }
      G = 0;
      switch (z % 4) {
      case 3:
          G = (K.charCodeAt(h + 2) & 0xff) << 16;
      case 2:
          G |= (K.charCodeAt(h + 1) & 0xff) << 8;
      case 1:
          G |= K.charCodeAt(h) & 0xff;
          G = l(G, T);
          G = (G & 0x1ffff) << 15 | G >>> 17;
          G = l(G, x);
          O ^= G;
      }
      O ^= z;
      O ^= O >>> 16;
      O = l(O, 0x85ebca6b);
      O ^= O >>> 13;
      O = l(O, 0xc2b2ae35);
      O ^= O >>> 16;
      return O;
  };
  return {
      Y: N
  };
}();
s2BB.p3 = function() {
  return typeof s2BB.P3.Z3 === 'function' ? s2BB.P3.Z3.apply(s2BB.P3, arguments) : s2BB.P3.Z3;
}
;
s2BB.f3 = function() {
  return typeof s2BB.P3.Y === 'function' ? s2BB.P3.Y.apply(s2BB.P3, arguments) : s2BB.P3.Y;
}
;
s2BB.p2 = function() {
  return typeof s2BB.e2.Z3 === 'function' ? s2BB.e2.Z3.apply(s2BB.e2, arguments) : s2BB.e2.Z3;
}
;
s2BB.j6R = "device";
s2BB.i6R = 'wrong command/type in param force-rotate. Defaulting value to portrait';
s2BB.H6R = '#canvas';
s2BB.Z4 = true;
s2BB.C2 = function() {
  return typeof s2BB.e2.Y === 'function' ? s2BB.e2.Y.apply(s2BB.e2, arguments) : s2BB.e2.Y;
}
;
s2BB.y6R = 'mobile';
s2BB.g8 = "hidden";
s2BB.c7 = function() {
  return typeof s2BB.H7.U7 === 'function' ? s2BB.H7.U7.apply(s2BB.H7, arguments) : s2BB.H7.U7;
}
;
s2BB.f8 = "visible";
s2BB.l2 = function() {
  return typeof s2BB.e2.Y === 'function' ? s2BB.e2.Y.apply(s2BB.e2, arguments) : s2BB.e2.Y;
}
;
s2BB.c1 = 'play';
s2BB.H2R = 'Ad';
